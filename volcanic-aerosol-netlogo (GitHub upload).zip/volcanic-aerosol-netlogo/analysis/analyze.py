"""Reproduces every number, table and figure in the manuscript from data/Results.xlsx.
Usage (from the repository root):  python analysis/analyze.py
Requires: numpy, openpyxl, matplotlib."""
import re, json, os
import numpy as np, openpyxl
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

SITES = ["Seattle", "San Francisco", "Denver", "Dallas", "NYC", "Volcano"]
# NetLogo's `patch x y` rounds to the nearest patch; these are the monitored patches in the model.
PATCH = {"Seattle": (0, 2), "San Francisco": (-6, -10), "Denver": (19, -11),
         "Dallas": (22, -26), "NYC": (48, -4), "Volcano": (0, 0)}
THRESH = 0.01   # % of emitted aerosol; model-relative threshold used for "days above"
COL = ['#1b6ca8', '#2a9d8f', '#e9a23b', '#d1495b', '#5e4b8b']

def load(path):
    ws = openpyxl.load_workbook(path, read_only=True).worksheets[0]
    runs, row = [], None
    for r in ws.iter_rows(values_only=True):
        for c in r:
            if c is None: continue
            s = str(c).strip()
            m = re.match(r"Tick (\d+):", s)
            if m:
                if int(m.group(1)) == 1: runs.append([])
                row = [None] * 6; runs[-1].append(row); continue
            m = re.match(r"(Seattle|San Francisco|Denver|Dallas|NYC|Volcano):\s*(\S+)", s)
            if m: row[SITES.index(m.group(1))] = float(m.group(2))
    return np.array(runs, dtype=float)

def ms(v):
    return {"mean": float(np.mean(v)), "sd": float(np.std(v, ddof=1)), "runs": [float(x) for x in v]}

def main():
    A = load("data/Results.xlsx")            # shape (runs, days, sites)
    n, T, _ = A.shape
    assert T == 720 and not np.isnan(A).any()
    out = {"n_runs": n, "days": T, "threshold_percent": THRESH, "sites": {}}
    for k, s in enumerate(SITES):
        X = A[:, :, k]
        above = X > THRESH
        first = [int(np.argmax(a)) + 1 if a.any() else None for a in above]
        out["sites"][s] = {
            "patch": PATCH[s], "distance_patches": float(np.hypot(*PATCH[s])),
            "final_day720": ms(X[:, -1]), "mean": ms(X.mean(1)), "median": ms(np.median(X, 1)),
            "max": ms(X.max(1)), "min": ms(X.min(1)), "day_of_max": ms(X.argmax(1) + 1),
            "days_above": ms(above.sum(1)), "first_day_above": first,
            "first_nonzero_day": [int(np.argmax(x > 0)) + 1 for x in X],
            "share_first30": ms(X[:, :30].sum(1) / X.sum(1) * 100),
        }
    cities = SITES[:5]
    order = lambda key: ["".join(str(i) for i in np.argsort(-np.array([out["sites"][c][key]["runs"][r] for c in cities]))) for r in range(n)]
    out["rank_by_mean_each_run"] = order("mean"); out["rank_by_max_each_run"] = order("max")
    out["rank_by_final_each_run"] = order("final_day720"); out["rank_by_days_above_each_run"] = order("days_above")
    os.makedirs("figures", exist_ok=True)
    json.dump(out, open("analysis/stats.json", "w"), indent=1)

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
    # Figure 1: concentration versus time
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    d = np.arange(1, T + 1)
    for k, c in enumerate(cities):
        # centered 7-tick running mean of each run (shorter window at the two ends)
        Sm = np.array([[run[max(0, t - 3):t + 4, k].mean() for t in range(T)] for run in A])
        m = Sm.mean(0); sd = Sm.std(0, ddof=1)
        lo = np.maximum(m - sd, 1e-7)
        ax.fill_between(d, lo, m + sd, color=COL[k], alpha=0.22, lw=0)
        ax.plot(d, np.where(m > 0, m, np.nan), color=COL[k], lw=1.2, label=c if c != "NYC" else "New York City")
    ax.set_yscale("log"); ax.set_ylim(1e-5, 10); ax.set_xlim(0, 720)
    ax.set_xlabel("Time since eruption (ticks; 1 tick = 1 day)")
    ax.set_ylabel("Aerosol concentration (% of emitted amount)")
    ax.legend(ncol=5, loc="lower center", bbox_to_anchor=(0.5, 1.01), frameon=False, handlelength=1.5, columnspacing=1.2)
    ax.grid(True, which="major", color="0.88", lw=0.6); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)
    fig.tight_layout(); fig.savefig("figures/Figure1.png", dpi=300); plt.close(fig)

    # Figure 3: final-day concentrations
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    data = [A[:, -1, k] for k in range(5)]
    bp = ax.boxplot(data, widths=0.5, patch_artist=True, showfliers=False, medianprops=dict(color="black"))
    for b, c in zip(bp["boxes"], COL): b.set(facecolor=c, alpha=0.35, edgecolor=c)
    rng = np.random.default_rng(1)
    for k in range(5):
        ax.scatter(k + 1 + rng.uniform(-0.12, 0.12, n), data[k], s=16, color=COL[k], zorder=3, edgecolor="white", lw=0.4)
    ax.set_xticks(range(1, 6)); ax.set_xticklabels(["Seattle", "San\nFrancisco", "Denver", "Dallas", "New York\nCity"])
    ax.set_ylabel("Aerosol concentration on day 720\n(% of emitted amount)"); ax.set_ylim(0, None)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)
    fig.tight_layout(); fig.savefig("figures/Figure3.png", dpi=300); plt.close(fig)

    # Figure 2: model layout
    fig, ax = plt.subplots(figsize=(4.6, 4.6))
    ax.set_xlim(-50.5, 50.5); ax.set_ylim(-50.5, 50.5); ax.set_aspect("equal")
    ax.scatter([0], [0], marker="^", s=45, color="black", zorder=4)
    ax.annotate("Volcano (0, 0)", (0, 0), xytext=(-4, -9), textcoords="offset points", ha="right", fontsize=8)
    off = {"Seattle": (6, 4), "San Francisco": (-6, -4), "Denver": (6, 4), "Dallas": (6, -10), "NYC": (-6, 6)}
    for k, c in enumerate(cities):
        x, y = PATCH[c]; ax.scatter([x], [y], s=45, color=COL[k], zorder=3)
        nm = "New York City" if c == "NYC" else c
        ax.annotate(f"{nm} ({x}, {y})", (x, y), xytext=off[c], textcoords="offset points",
                    ha="left" if off[c][0] > 0 else "right", fontsize=8)
    ax.set_xlabel("Patch x-coordinate"); ax.set_ylabel("Patch y-coordinate")
    ax.set_xticks(range(-50, 51, 25)); ax.set_yticks(range(-50, 51, 25)); ax.grid(True, color="0.9", lw=0.6); ax.set_axisbelow(True)
    fig.tight_layout(); fig.savefig("figures/Figure2.png", dpi=300); plt.close(fig)

    lab = [("Day 720", "final_day720", 4), ("Average", "mean", 4), ("Median", "median", 4), ("Maximum", "max", 4),
           ("Minimum", "min", 4), ("Day of maximum", "day_of_max", 0), (f"Days above {THRESH}%", "days_above", 0)]
    for name, key, p in lab:
        print(f"{name:18s}", "  ".join(f"{out['sites'][s][key]['mean']:.{p}f}±{out['sites'][s][key]['sd']:.{p}f}" for s in SITES))
    for k in ("rank_by_mean_each_run", "rank_by_max_each_run", "rank_by_days_above_each_run", "rank_by_final_each_run"): print(k, out[k])
    for s in cities: print(s, "dist %.1f" % out["sites"][s]["distance_patches"], "first>thr", out["sites"][s]["first_day_above"], "first nonzero", out["sites"][s]["first_nonzero_day"], "share30 %.1f-%.1f" % (min(out["sites"][s]["share_first30"]["runs"]), max(out["sites"][s]["share_first30"]["runs"])))
    for s in SITES: print(s, "day of max per run", out["sites"][s]["day_of_max"]["runs"], "min", out["sites"][s]["min"]["runs"])

if __name__ == "__main__":
    main()
