"""Python re-implementation of 'No Wind Code.nlogo' diffuse-aerosols (NetLogo 6.4 semantics:
ask patches = random order, sequential updates; world -50..50 torus)."""
import numpy as np, sys
N=101; OFF=50
MON=[(0,2),(-6,-10),(19,-11),(22,-26),(48,-4),(0,0)]  # NetLogo `patch` rounds coordinates
NB=[(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
def run(seed,T=720):
    rng=np.random.default_rng(seed)
    c=[0.0]*(N*N); c[OFF*N+OFF]=100.0
    d=0.01**(1/730)
    nbr=[[((x+dx)%N)*N+(y+dy)%N for dx,dy in NB] for x in range(N) for y in range(N)]
    out=np.zeros((T,6)); tot=np.zeros(T)
    for t in range(T):
        for i in rng.permutation(N*N):
            a=c[i]
            if a>0:
                s=0.99*a; p=s/8
                for j in nbr[i]: c[j]+=p
                c[i]=(c[i]-s)*d
        out[t]=[c[(x+OFF)*N+(y+OFF)] for x,y in MON]; tot[t]=sum(c)
    return out,tot
if __name__=="__main__":
    n=int(sys.argv[1]); R=[];TT=[]
    for s in range(n):
        o,t=run(s); R.append(o); TT.append(t[-1]); print(s,t[-1],flush=True)
    np.save("sim_nowind.npy",np.array(R)); np.save("sim_tot.npy",np.array(TT))
