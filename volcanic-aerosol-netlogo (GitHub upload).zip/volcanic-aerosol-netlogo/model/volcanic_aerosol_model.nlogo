; Define global variables and patch properties as before

globals [
  volcano                 ; A reference to the volcano patch
  aerosol-density         ; (Unused in the shown code) Could be a global setting for aerosol density
  volcano-xcor            ; X coordinate (pxcor) of volcano
  volcano-ycor            ; Y coordinate (pycor) of volcano
  monitored-points        ; List of patches whose aerosol concentrations we track
  concentration-history   ; A running list of aerosol concentrations at monitored points over time
]

patches-own [ ; patch-specific properties
  aerosol-concentration  ; Amount of aerosol present in that patch
  daily-decay ;amount of aeroosl decay fuction
]

to setup
  clear-all                                                                    ; resets simulation
  setup-world                                                                  ; configures the patch grid and initializes patch variables
  if not (volcano-xcor >= min-pxcor and volcano-xcor <= max-pxcor and          ; check if volcano coords are within the world boundaries
          volcano-ycor >= min-pycor and volcano-ycor <= max-pycor) [
    user-message "Volcano coordinates are out of bounds. Please correct them."
    stop
  ]
  set-volcano-coordinates 0 0                                               ; sets the volcano’s position NOTE: SHOULD THIS BE 0,0 ?
  create-volcano                                                               ; marks that patch as the volcano patch

  define-monitored-points                                                      ; sets a list of key patches to track aerosol concentration (corners + center).
  let city-names ["Seattle" "San Francisco" "Denver" "Dallas" "NYC" "Volcano"] ; defines corresponding city names
  explode-volcano                                                              ; sets the volcano patch’s aerosol concentration to a high value (100) and colors it orange.
  setup-plots                                                                  ; prepare the NetLogo plotting interface
  update-plots                                                                 ; ""
  reset-ticks                                                                  ; starts the simulation clock at zero
end


to setup-world
  resize-world -50 50 -50 50     ; Sets the NetLogo world to range from -50 to 50 (x and y)
  ask patches [
    set aerosol-concentration 0  ; initialize aerosol concentration to 0
    set pcolor scale-color blue aerosol-concentration 0 100 ; color patch by aerosol concentration (0 (blue, low) to 100)
  ]
end

to set-volcano-coordinates [lat lon]
  set volcano-xcor lat
  set volcano-ycor lon
  print (word "Setting volcano coordinates to: (" volcano-xcor ", " volcano-ycor ")")
end

to create-volcano
  set volcano patch volcano-xcor volcano-ycor
  ifelse volcano != nobody [
    ask volcano [
      set pcolor brown  ; Change the volcano to brown
    ]
  ] [
    user-message "Error: Volcano patch could not be set."
    stop
  ]
end

to define-monitored-points
  ; Define monitored points at the corners and center of the world
  set monitored-points (list patch -0.11 1.69  ; Seattle (1)
                              patch -6 -10.39  ; San Fransisco (2)
                              patch 19.05 -11  ; Denver (3)
                              patch 21.86 -26.04  ; Dallas (4)
                              patch 47.81 -4.18  ; NYC (5)
                              patch 0 0)                 ; Center, volcano (6)

  ; Initialize the history for these monitored points
  set concentration-history []

  ; Visualize monitored points with green patches
  foreach monitored-points [monitored-point ->
    if monitored-point != nobody [
      ask monitored-point [
        set pcolor green  ; Highlight monitored points in green
      ]
    ]
  ]
end

to explode-volcano
  ask volcano [
    set pcolor orange
    set aerosol-concentration 100  ; Initialize high concentration on the volcano
  ]
end


to go
  ;optional: I've built this in so that (maybe) the volcano keeps erupting for the first 50 ticks (eg. 50 mins)
  if ticks < 1 [
    ; For the first 1 ticks, keep the volcano erupting at 100%
    ask volcano [
      set aerosol-concentration 100
    ]
  ]
  if ticks >= 720 [ stop ]  ; End simulation after 720 days/ticks (2 years)
  tick
  diffuse-aerosols
  record-concentration
  print-aerosol-data  ; Log concentrations to the Command Center
  update-patch-colors
  plot-aerosol-data  ; Renamed from update-plots/refresh-plots
end


to diffuse-aerosols
  ask patches [
    if aerosol-concentration > 0 [
      ;; Decide how much of the patch's aerosol to share
      let share-fraction 0.99  ; e.g., 99% of this patch's aerosol is shared each tick
      let amount-to-share share-fraction * aerosol-concentration

      ;; Get this patch's neighbors (the 8 surrounding patches in Moore neighborhood (8 = 360 degrees, 4 patches = strictly up/down/left/right)
      let nbrs neighbors
      let num-nbrs count nbrs

      if (num-nbrs > 0) [
        ;; Each neighbor gets an equal fraction of the total shared aerosol
        let portion amount-to-share / num-nbrs

        ;; Give a portion to each neighbor
        ask nbrs [
          set aerosol-concentration aerosol-concentration + portion
        ]

        ;; Subtract the shared amount from the current patch
        set aerosol-concentration aerosol-concentration - amount-to-share
      ]

      ;; Exponential decay so that after 730 days, only 1% remains
      let daily-decay-factor 0.01 ^ (1.0 / 730)
      set aerosol-concentration aerosol-concentration * daily-decay-factor
    ]
  ]
end


to update-patch-colors
  ; Update patch colors based on aerosol concentration (exclude volcano and monitoring points)
  ask patches with [
    (self != volcano) and not member? self monitored-points
  ] [
    set pcolor scale-color blue aerosol-concentration 0 100
  ]
end

to record-concentration
  let current-data []
  foreach monitored-points [monitored-point ->
    let density [aerosol-concentration] of monitored-point
    set current-data lput density current-data
  ]
  set concentration-history lput current-data concentration-history
end

; MARY ADDED THIS SO WE CAN PRINT (NOT JUST GRAPH) IT
to print-aerosol-data
  print (word "Tick " ticks ":")
  let city-names ["Seattle" "San Francisco" "Denver" "Dallas" "NYC" "Volcano"]
  (foreach (n-values (length monitored-points) [? -> ?]) [
    [i] ->
      let mp item i monitored-points
      let city item i city-names
      print (word "  " city ": " [aerosol-concentration] of mp)
  ])
end



to initialize-plots
  ; Define plot settings for tracking aerosol concentration at each point
  set-current-plot "Aerosol Concentration"
  set-plot-x-range 0 100  ; Adjust range as needed
  set-plot-y-range 0 100  ; Adjust range for aerosol concentration values

  foreach monitored-points [monitored-point ->
    let pen-label word "Point " monitored-point
    set-current-plot-pen pen-label
    let density [aerosol-concentration] of monitored-point  ; Get the current aerosol concentration
    plot density
  ]
end

; OLD VERSION
; to plot-aerosol-data
;  set-current-plot "Aerosol Concentration" ; tells NetLogo what we're about to write to
;  let counter 1
;  foreach monitored-points [monitored-point ->
;    let density [aerosol-concentration] of monitored-point
;    set-current-plot-pen word "Point-" counter
;    plot density
;    set counter counter + 1
;  ]
;end

; NEW VERSION
to plot-aerosol-data
  set-current-plot "Aerosol Concentration" ; tells NetLogo what we're about to write to
  let pen-index 1
  foreach monitored-points [ mp -> ; iterate over each patch in monitored-points
    ; Create or select the pen for this point
    set-current-plot-pen word "Point-" pen-index

    ; Plot the current aerosol concentration on the Y axis,
    ; and let NetLogo handle the X axis as ticks
    plot [aerosol-concentration] of mp

    set pen-index pen-index + 1
  ]
end
@#$#@#$#@
GRAPHICS-WINDOW
440
10
961
532
-1
-1
5.08
1
10
1
1
1
0
1
1
1
-50
50
-50
50
0
0
1
ticks
30.0

BUTTON
681
544
747
577
setup
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
781
543
844
576
Go
go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

MONITOR
5
392
236
437
Current Aerosol Density at Volcano
[aerosol-concentration] of volcano
17
1
11

MONITOR
6
339
152
384
Total Aerosol Density
sum [aerosol-concentration] of patches
17
1
11

PLOT
4
10
435
332
Aerosol Concentration
Time
Aerosol Concentration
0.0
725.0
0.0
10.0
true
false
"" ""
PENS
"default" 1.0 0 -16777216 true "" "plot count turtles"
"Point-1" 1.0 0 -7500403 true "" ""
"Point-2" 1.0 0 -2674135 true "" ""
"Point-3" 1.0 0 -955883 true "" ""
"Point-4" 1.0 0 -6459832 true "" ""
"Point-5" 1.0 0 -1184463 true "" ""
"Point-6" 1.0 0 -10899396 true "" ""

@#$#@#$#@
## WHAT IS IT?

(a general understanding of what the model is trying to show or explain)

## HOW IT WORKS

(what rules the agents use to create the overall behavior of the model)

## HOW TO USE IT

(how to use the model, including a description of each of the items in the Interface tab)

## THINGS TO NOTICE

(suggested things for the user to notice while running the model)

## THINGS TO TRY

(suggested things for the user to try to do (move sliders, switches, etc.) with the model)

## EXTENDING THE MODEL

(suggested things to add or change in the Code tab to make the model more complicated, detailed, accurate, etc.)

## NETLOGO FEATURES

(interesting or unusual features of NetLogo that the model uses, particularly in the Code tab; or where workarounds were needed for missing features)

## RELATED MODELS

(models in the NetLogo Models Library and elsewhere which are of related interest)

## CREDITS AND REFERENCES

(a reference to the model's URL on the web if it has one, as well as any other necessary credits, citations, and links)
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

sheep
false
15
Circle -1 true true 203 65 88
Circle -1 true true 70 65 162
Circle -1 true true 150 105 120
Polygon -7500403 true false 218 120 240 165 255 165 278 120
Circle -7500403 true false 214 72 67
Rectangle -1 true true 164 223 179 298
Polygon -1 true true 45 285 30 285 30 240 15 195 45 210
Circle -1 true true 3 83 150
Rectangle -1 true true 65 221 80 296
Polygon -1 true true 195 285 210 285 210 240 240 210 195 210
Polygon -7500403 true false 276 85 285 105 302 99 294 83
Polygon -7500403 true false 219 85 210 105 193 99 201 83

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

wolf
false
0
Polygon -16777216 true false 253 133 245 131 245 133
Polygon -7500403 true true 2 194 13 197 30 191 38 193 38 205 20 226 20 257 27 265 38 266 40 260 31 253 31 230 60 206 68 198 75 209 66 228 65 243 82 261 84 268 100 267 103 261 77 239 79 231 100 207 98 196 119 201 143 202 160 195 166 210 172 213 173 238 167 251 160 248 154 265 169 264 178 247 186 240 198 260 200 271 217 271 219 262 207 258 195 230 192 198 210 184 227 164 242 144 259 145 284 151 277 141 293 140 299 134 297 127 273 119 270 105
Polygon -7500403 true true -1 195 14 180 36 166 40 153 53 140 82 131 134 133 159 126 188 115 227 108 236 102 238 98 268 86 269 92 281 87 269 103 269 113

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.4.0
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
