# Volcanic aerosol NetLogo model

Model, simulation output, and analysis code for "Volcanic Aerosols Under Climate Change: Simulating a Volcanic Eruption and its Aerosol Concentrations" (Pranit Kosaraju and Mary Burak, Journal of Emerging Investigators, manuscript JEI-26-102).

## Contents

- `model/volcanic_aerosol_model.nlogo` is the NetLogo 6.4.0 model that produced the data in the paper.
- `data/Results.xlsx` holds the recorded output of six runs of 720 ticks each. The first sheet lists the concentration at Seattle, San Francisco, Denver, Dallas, New York City, and the volcano patch on every tick.
- `analysis/analyze.py` reads the data and reproduces Table 1, the numbers in the Results section, and Figures 1 to 3.
- `analysis/stats.json` is the output of that script, including the value for each run.
- `analysis/reimplementation_check.py` is an independent Python version of the model's spreading rule, used to confirm how the model behaves.
- `figures/` holds the three figures as PNG files at 300 dpi.

## How the model works

The world is a 101 x 101 grid of patches with coordinates from -50 to 50 that wraps at its edges. The volcano is the patch at (0, 0) and starts with an aerosol concentration of 100. On each tick (one day), every patch that holds aerosol gives 99% of it to its eight neighbors in equal shares, keeps 1%, and multiplies what it kept by a decay factor of 0.01^(1/730). NetLogo updates patches one at a time in random order, so runs differ from one another. There is no wind. Because the decay factor only acts on the 1% that a patch keeps, the total in the world falls slowly, to about 92.7 after 720 ticks.

## Running the model

Open the `.nlogo` file in NetLogo 6.4.0, press `setup`, then `go`. The concentration at each monitored patch prints to the Command Center on every tick and the run stops at tick 720.

## Reproducing the analysis

```
pip install numpy openpyxl matplotlib
python analysis/analyze.py
```
